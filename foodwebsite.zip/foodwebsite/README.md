# FoodWebsite

A Pen created on CodePen.

Original URL: [https://codepen.io/Bhargav-Sai-Ram-Nakkanaboina/pen/bNVPaLG](https://codepen.io/Bhargav-Sai-Ram-Nakkanaboina/pen/bNVPaLG).

Built responsive website using HTML, Tailwind CSS, and JavaScript
- Implemented cart functionality, animations, and mobile-first design
- Features product catalog, testimonials, and newsletter subscription